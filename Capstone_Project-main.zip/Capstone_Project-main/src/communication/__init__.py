"""Communication layer for the distributed system."""

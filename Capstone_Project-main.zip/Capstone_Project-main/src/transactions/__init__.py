"""Transaction management for distributed transactions."""

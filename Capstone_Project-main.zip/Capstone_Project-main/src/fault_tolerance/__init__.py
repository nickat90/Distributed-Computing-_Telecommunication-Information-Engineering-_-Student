"""Fault tolerance mechanisms."""

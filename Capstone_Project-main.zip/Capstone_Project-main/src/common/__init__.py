"""Common utilities and shared code for the distributed system."""

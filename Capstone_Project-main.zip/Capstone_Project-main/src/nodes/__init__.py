"""Node implementations for edge, core, and cloud."""

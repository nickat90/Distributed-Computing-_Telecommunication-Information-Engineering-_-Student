"""GUI application for the distributed system."""
